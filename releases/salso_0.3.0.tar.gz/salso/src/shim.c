void R_init_salso_librust(void *dll);
void R_init_salso(void *dll) { R_init_salso_librust(dll); }
