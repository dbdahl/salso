#' @docType package
#' @usage NULL
#' @useDynLib salso, .registration = TRUE
NULL
